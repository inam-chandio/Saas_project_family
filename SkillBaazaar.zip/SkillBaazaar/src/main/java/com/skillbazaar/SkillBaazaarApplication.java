package com.skillbazaar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillBaazaarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillBaazaarApplication.class, args);
	}

}
