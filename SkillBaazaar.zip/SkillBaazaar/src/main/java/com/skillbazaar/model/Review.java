package com.skillbazaar.model;

public class Review {
    private Long id;
    private Long userId;
    private Long jobId;
    private int rating;
    private String comment;

    public Review(Long id, Long userId, Long jobId, int rating, String comment) {
        this.id = id;
        this.userId = userId;
        this.jobId = jobId;
        this.rating = rating;
        this.comment = comment;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getJobId() {
        return jobId;
    }

    public void setJobId(Long jobId) {
        this.jobId = jobId;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
